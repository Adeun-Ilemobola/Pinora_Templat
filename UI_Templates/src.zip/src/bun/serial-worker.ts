import { SerialPort } from "serialport";
import { createInterface } from "node:readline";

const input = createInterface({
  input: process.stdin,
});

console.error("Serial worker started");

let port: SerialPort | undefined;

input.on("line", async (line) => {
  try {
    const message = JSON.parse(line);

    if (message.type === "list") {
      const ports = await SerialPort.list();

      send({
        type: "ports",
        id: message.id,
        ports,
      });

      return;
    }

    if (message.type === "open") {
      port = new SerialPort({
        path: message.path,
        baudRate: message.baudRate,
        autoOpen: false,
      });

      port.on("data", (data) => {
        send({
          type: "data",
          data: data.toString("base64"),
        });
      });

      port.on("error", (error) => {
        send({
          type: "error",
          message: error.message,
        });
      });

      port.on("close", () => {
        send({
          type: "closed",
        });
      });

      port.open(async (error) => {
        if (error) {
          send({
            type: "error",
            message: error.message,
          });
          return;
        }

        send({
          type: "opened",
          path: message.path,
        });

        // ESP32 reset pulse
        port?.set({ dtr: false, rts: true }, () => {
          setTimeout(() => {
            port?.set({ dtr: true, rts: false });
          }, 100);
        });
      });

      return;
    }

    if (message.type === "write") {
      if (!port?.isOpen) {
        throw new Error("Serial port is not open");
      }

      port.write(Buffer.from(message.data, "base64"));
      return;
    }

    if (message.type === "close") {
      if (port?.isOpen) {
        port.close();
      }

      port = undefined;
      return;
    }
  } catch (error) {
    send({
      type: "error",
      message: error instanceof Error ? error.message : String(error),
    });
  }
});

function send(message: unknown) {
  process.stdout.write(JSON.stringify(message) + "\n");
}
