import { BrowserWindow, BrowserView } from "electrobun/bun";
import type { AppRPC, SerialDeviceInfo } from "@src/bun/rpc";
import z from "zod";
import { InComingMessageSchema } from "@src/bun/Protocol/ModuleDefinitionSchema";
import { join } from "node:path";
import { SerialPort } from "serialport";

const workerPath = join(import.meta.dir, "serial-worker.ts");
type SerialWorkerProcess = Bun.Subprocess<"pipe", "pipe", "inherit">;
type SerialWorkerCommand =
  | { type: "open"; path: string; baudRate: number }
  | { type: "write"; data: string }
  | { type: "close" };
type SerialWorkerEvent =
  | { type: "opened"; path: string }
  | { type: "data"; data: string }
  | { type: "error"; message: string }
  | { type: "closed" };

let serialWorker: SerialWorkerProcess | null = null;
let activePortPath: string | null = null;
let serialLineBuffer = "";
let serialDecoder = new TextDecoder();

const DEV_SERVER_URL = "http://localhost:5173";

function parseWorkerEvent(text: string): SerialWorkerEvent | null {
  try {
    return JSON.parse(text) as SerialWorkerEvent;
  } catch {
    console.error("Invalid message from serial worker:", text);
    return null;
  }
}

function sendWorkerCommand(command: SerialWorkerCommand) {
  if (!serialWorker) {
    throw new Error("Serial worker is not running");
  }

  serialWorker.stdin.write(`${JSON.stringify(command)}\n`);
  serialWorker.stdin.flush();
}

function forwardSerialLine(line: string) {
  const text = line.trim();
  if (!text) return;

  try {
    const parsedMessage = InComingMessageSchema.safeParse(JSON.parse(text));

    if (!parsedMessage.success) {
      console.error(
        "[ListenStore] invalid incoming message:",
        z.prettifyError(parsedMessage.error),
      );
      return;
    }

    mainWindow.webview.rpc?.send.incomingMessage({
      message: parsedMessage.data,
    });
  } catch (error) {
    console.error("Invalid JSON from ESP32:", text, error);
  }
}

function handleSerialData(encodedData: string) {
  const bytes = Buffer.from(encodedData, "base64");
  serialLineBuffer += serialDecoder.decode(bytes, { stream: true });

  let newlineIndex = serialLineBuffer.indexOf("\n");
  while (newlineIndex !== -1) {
    const line = serialLineBuffer.slice(0, newlineIndex);
    serialLineBuffer = serialLineBuffer.slice(newlineIndex + 1);
    forwardSerialLine(line);
    newlineIndex = serialLineBuffer.indexOf("\n");
  }
}

function handleWorkerEvent(event: SerialWorkerEvent, portPath: string) {
  switch (event.type) {
    case "opened":
      console.log("Serial port opened:", event.path);
      mainWindow.webview.rpc?.send.PortStatus({
        path: event.path,
        status: "connected",
      });
      break;
    case "data":
      handleSerialData(event.data);
      break;
    case "error":
      console.error("Serial worker error:", event.message);
      mainWindow.webview.rpc?.send.PortStatus({
        path: portPath,
        status: "error",
      });
      break;
    case "closed":
      mainWindow.webview.rpc?.send.PortStatus({
        path: portPath,
        status: "disconnected",
      });
      break;
  }
}

async function readWorkerOutput(
  worker: SerialWorkerProcess,
  portPath: string,
) {
  const reader = worker.stdout.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      let newlineIndex = buffer.indexOf("\n");

      while (newlineIndex !== -1) {
        const line = buffer.slice(0, newlineIndex).trim();
        buffer = buffer.slice(newlineIndex + 1);

        if (line) {
          const event = parseWorkerEvent(line);
          if (event) handleWorkerEvent(event, portPath);
        }

        newlineIndex = buffer.indexOf("\n");
      }
    }
  } catch (error) {
    console.error("Failed to read serial worker output:", error);
  } finally {
    reader.releaseLock();
  }
}

async function monitorWorker(worker: SerialWorkerProcess, portPath: string) {
  const exitCode = await worker.exited;
  if (serialWorker !== worker) return;

  serialWorker = null;
  activePortPath = null;
  console.log(`Serial worker exited with code ${exitCode}`);
  mainWindow.webview.rpc?.send.PortStatus({
    path: portPath,
    status: exitCode === 0 ? "disconnected" : "error",
  });
}

async function getMainViewUrl(): Promise<string> {
  try {
    const response = await fetch(DEV_SERVER_URL, {
      method: "HEAD",
      signal: AbortSignal.timeout(1000),
    });

    if (response.ok) {
      console.log(`HMR enabled: ${DEV_SERVER_URL}`);
      return DEV_SERVER_URL;
    }
  } catch {
    console.log("Vite server unavailable; using bundled view.");
  }

  return "views://mainview/index.html";
}

export const rpc = BrowserView.defineRPC<AppRPC>({
  handlers: {
    requests: {
      async getAvailablePorts(): Promise<SerialDeviceInfo[]> {
        console.log("Loading serialport...");

        const ports = await SerialPort.list();


        return ports.map((port: any) => ({
          path: port.path,
          manufacturer: port.manufacturer ?? null,
          serialNumber: port.serialNumber ?? null,
          vendorId: port.vendorId ?? null,
          productId: port.productId ?? null,
          locationId: port.locationId ?? null,
          pnpId: port.pnpId ?? null,
        }));
      },
      async openPort({ port }) {
        try {
          mainWindow.webview.rpc?.send.PortStatus({
            path: port,
            status: "connecting",
          });

          if (!(await Bun.file(workerPath).exists())) {
            throw new Error(`Serial worker was not packaged at ${workerPath}`);
          }

          if (serialWorker) {
            serialWorker.kill();
            serialWorker = null;
          }

          activePortPath = port;
          serialLineBuffer = "";
          serialDecoder = new TextDecoder();

          const child = Bun.spawn({
            cmd: [process.execPath, workerPath],
            stdin: "pipe",
            stdout: "pipe",
            stderr: "inherit",
          });

          serialWorker = child;

          console.log("Serial worker PID:", child.pid);
          void readWorkerOutput(child, port);
          void monitorWorker(child, port);

          sendWorkerCommand({
            type: "open",
            path: port,
            baudRate: 115200,
          });

          return {};

        } catch (error) {
          serialWorker = null;
          activePortPath = null;
          console.error("Failed to start serial worker:", error);
          mainWindow.webview.rpc?.send.PortStatus({
            path: port,
            status: "error",
          });
          throw error;
        }
      },

      async sendComand(params) {
        try {
          if (!serialWorker || !activePortPath) {
            throw new Error("No serial port is connected");
          }

          const sendData = `${JSON.stringify(params)}\n`;
          sendWorkerCommand({
            type: "write",
            data: Buffer.from(sendData, "utf8").toString("base64"),
          });
          return {};

        } catch (error) {
          console.error("Command write failed:", error);
          throw error;
        }

      },
    },
    messages: {},
  },
});

console.log("Resolving main view URL...");

const url = await getMainViewUrl();

console.log("Creating window with URL:", url);

const mainWindow = new BrowserWindow({
  title: "UI_Templates",
  url,
  frame: {
    width: 1000,
    height: 720,
    x: 200,
    y: 200,
  },
  rpc,
});

console.log("UI_Templates window created.");
